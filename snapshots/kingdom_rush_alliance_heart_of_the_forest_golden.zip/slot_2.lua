local obj1 = {
	["achievement_counters"] = {
		["MIGHTY_I"] = 246;
		["MIGHTY_II"] = 246;
		["MIGHTY_III"] = 246;
		["NOT_A_MOMENT_TO_WASTE"] = 7;
		["SAVIOUR_OF_THE_GREEN"] = 2;
		["SIGNATURE_TECHNIQUES"] = 15;
		["THE_CAVALRY_IS_HERE"] = 50;
		["UNENDING_RICHES"] = 1728;
		["WAR_MASONRY"] = 18;
	};
	["achievements"] = {
		["LEARNING_THE_ROPES"] = true;
	};
	["achievements_claimed"] = {
	};
	["bag"] = {
	};
	["claimed_gifts"] = {
	};
	["difficulty"] = 2;
	["gems"] = 102;
	["heroes"] = {
		["selected"] = "hero_vesper";
		["status"] = {
			["hero_bird"] = {
				["skills"] = {
					["cluster_bomb"] = 0;
					["eat_instakill"] = 0;
					["gattling"] = 0;
					["shout_stun"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_builder"] = {
				["skills"] = {
					["defensive_turret"] = 0;
					["demolition_man"] = 0;
					["lunch_break"] = 0;
					["overtime_work"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_dragon_arb"] = {
				["skills"] = {
					["arborean_spawn"] = 0;
					["thorn_bleed"] = 0;
					["tower_plants"] = 0;
					["tower_runes"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_dragon_bone"] = {
				["skills"] = {
					["burst"] = 0;
					["cloud"] = 0;
					["nova"] = 0;
					["rain"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_dragon_gem"] = {
				["skills"] = {
					["crystal_instakill"] = 0;
					["crystal_totem"] = 0;
					["floor_impact"] = 0;
					["stun"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_dragon_sun"] = {
				["skills"] = {
					["overcharge"] = 0;
					["solar_cleansing"] = 0;
					["solar_stones"] = 0;
					["ultimate"] = 1;
					["worthy_foe"] = 0;
				};
				["xp"] = 0;
			};
			["hero_hunter"] = {
				["skills"] = {
					["beasts"] = 0;
					["heal_strike"] = 0;
					["ricochet"] = 0;
					["shoot_around"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_lava"] = {
				["skills"] = {
					["double_trouble"] = 0;
					["hotheaded"] = 0;
					["temper_tantrum"] = 0;
					["ultimate"] = 1;
					["wild_eruption"] = 0;
				};
				["xp"] = 0;
			};
			["hero_lumenir"] = {
				["skills"] = {
					["celestial_judgement"] = 0;
					["fire_balls"] = 0;
					["mini_dragon"] = 0;
					["shield"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_mecha"] = {
				["skills"] = {
					["goblidrones"] = 0;
					["mine_drop"] = 0;
					["power_slam"] = 0;
					["tar_bomb"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_muyrn"] = {
				["skills"] = {
					["faery_dust"] = 0;
					["leaf_whirlwind"] = 0;
					["sentinel_wisps"] = 0;
					["ultimate"] = 1;
					["verdant_blast"] = 0;
				};
				["xp"] = 0;
			};
			["hero_raelyn"] = {
				["skills"] = {
					["brutal_slash"] = 0;
					["inspire_fear"] = 0;
					["onslaught"] = 0;
					["ultimate"] = 1;
					["unbreakable"] = 0;
				};
				["xp"] = 2506;
			};
			["hero_robot"] = {
				["skills"] = {
					["explode"] = 0;
					["fire"] = 0;
					["jump"] = 0;
					["ultimate"] = 1;
					["uppercut"] = 0;
				};
				["xp"] = 0;
			};
			["hero_space_elf"] = {
				["skills"] = {
					["astral_reflection"] = 0;
					["black_aegis"] = 0;
					["spatial_distortion"] = 0;
					["ultimate"] = 1;
					["void_rift"] = 0;
				};
				["xp"] = 0;
			};
			["hero_spider"] = {
				["skills"] = {
					["area_attack"] = 0;
					["instakill_melee"] = 0;
					["supreme_hunter"] = 0;
					["tunneling"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_venom"] = {
				["skills"] = {
					["eat_enemy"] = 0;
					["floor_spikes"] = 0;
					["inner_beast"] = 0;
					["ranged_tentacle"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_vesper"] = {
				["skills"] = {
					["arrow_to_the_knee"] = 0;
					["disengage"] = 0;
					["martial_flourish"] = 0;
					["ricochet"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 3810;
			};
			["hero_witch"] = {
				["skills"] = {
					["disengage"] = 0;
					["path_aoe"] = 0;
					["polymorph"] = 0;
					["soldiers"] = 0;
					["ultimate"] = 1;
				};
				["xp"] = 0;
			};
			["hero_wukong"] = {
				["skills"] = {
					["giant_staff"] = 0;
					["hair_clones"] = 0;
					["pole_ranged"] = 0;
					["ultimate"] = 1;
					["zhu_apprentice"] = 0;
				};
				["xp"] = 0;
			};
		};
		["team"] = {
			[1] = "hero_vesper";
			[2] = "hero_raelyn";
		};
	};
	["items"] = {
		["selected"] = {
			[1] = "cluster_bomb";
			[2] = "portable_coil";
			[3] = "winter_age";
		};
		["status"] = {
			["cluster_bomb"] = 0;
			["deaths_touch"] = 0;
			["loot_box"] = 0;
			["medical_kit"] = 0;
			["portable_coil"] = 0;
			["scroll_of_spaceshift"] = 0;
			["second_breath"] = 0;
			["summon_blackburn"] = 0;
			["veznan_wrath"] = 0;
			["winter_age"] = 0;
		};
	};
	["levels"] = {
		[1] = {
			[1] = 2;
			["stars"] = 3;
		};
		[2] = {
			[1] = 2;
			["stars"] = 3;
		};
		[3] = {
		};
		[23] = {
		};
		[31] = {
		};
		[36] = {
		};
	};
	["seen"] = {
		["POWER_REINFORCEMENT"] = true;
		["TIP_ARMOR"] = true;
		["TIP_RALLY"] = true;
		["TUTORIAL_HERO"] = true;
		["arcane_wizard"] = true;
		["difficulty"] = true;
		["dragons"] = true;
		["dwarf"] = true;
		["enemy_bear_vanguard"] = true;
		["enemy_cutthroat_rat"] = true;
		["enemy_hog_invader"] = true;
		["enemy_tusked_brawler"] = true;
		["flag_1"] = true;
		["hero_dragon_sun"] = true;
		["hero_lava"] = true;
		["hero_raelyn"] = true;
		["hero_vesper"] = true;
		["hero_wukong"] = true;
		["paladin_covenant"] = true;
		["pandas"] = true;
		["royal_archers"] = true;
		["tower_arcane_wizard_lvl1"] = true;
		["tower_arcane_wizard_lvl2"] = true;
		["tower_build_arcane_wizard"] = true;
		["tower_build_paladin_covenant"] = true;
		["tower_build_royal_archers"] = true;
		["tower_build_tricannon"] = true;
		["tower_holder_sea_of_trees"] = true;
		["tower_paladin_covenant_lvl1"] = true;
		["tower_paladin_covenant_lvl2"] = true;
		["tower_royal_archers_lvl1"] = true;
		["tower_royal_archers_lvl2"] = true;
		["tower_tricannon_lvl1"] = true;
		["tower_tricannon_lvl2"] = true;
		["tricannon"] = true;
		["tutorial_hero_room"] = true;
		["tutorial_tower_room"] = true;
		["tutorial_upgrades_room"] = true;
	};
	["towers"] = {
		["selected"] = {
			[1] = "royal_archers";
			[2] = "paladin_covenant";
			[3] = "arcane_wizard";
			[4] = "tricannon";
		};
		["status"] = {
			["arborean_emissary"] = {
			};
			["arcane_wizard"] = {
			};
			["ballista"] = {
			};
			["barrel"] = {
			};
			["dark_elf"] = {
			};
			["demon_pit"] = {
			};
			["dragons"] = {
			};
			["dwarf"] = {
			};
			["elven_stargazers"] = {
			};
			["flamespitter"] = {
			};
			["ghost"] = {
			};
			["hermit_toad"] = {
			};
			["necromancer"] = {
			};
			["paladin_covenant"] = {
			};
			["pandas"] = {
			};
			["ray"] = {
			};
			["rocket_gunners"] = {
			};
			["royal_archers"] = {
			};
			["sand"] = {
			};
			["sparking_geode"] = {
			};
			["tricannon"] = {
			};
		};
	};
	["upgrades"] = {
		["alliance"] = {
		};
		["heroes"] = {
		};
		["reinforcements"] = {
		};
		["towers"] = {
		};
	};
	["version_string"] = "kr5-desktop-7.00.62";
}
return obj1
